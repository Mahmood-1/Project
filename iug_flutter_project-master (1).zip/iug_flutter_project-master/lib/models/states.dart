// ignore_for_file: camel_case_types

abstract class All_Statels{}
class initialStates extends All_Statels{

}class isShoping extends All_Statels{

}

class isFavorting extends All_Statels{

}

class is_cout_plus extends All_Statels{

}
class is_cout_minus extends All_Statels{

}

class isFavort_prdects extends All_Statels{

}

class isshopp_prdecting extends All_Statels{

}
class cont_ordering_plus extends All_Statels{
}
class cont_ordering_minus extends All_Statels{

}
class ispasswored_stet extends All_Statels{ }

class user_R extends All_Statels{

}
class user_loding extends All_Statels{

}
class user_successful extends All_Statels{}
class user_error extends All_Statels{
final String error;
user_error(this.error);
}
class user_loOut extends All_Statels{
}


class lodiding extends All_Statels{

}

class ImagePicker_successful extends All_Statels{ }

class ImagePicker_error extends All_Statels{ }



class Add_new_prdect extends All_Statels{}
class Add_prdect_error extends All_Statels{}
class Add_prdect_successful extends All_Statels{}

class Get_prdect_error extends All_Statels{
  final String error;
  Get_prdect_error(this.error);
}
class Get_prdect_successful extends All_Statels{}

class get_error  extends All_Statels{}
class get_successful  extends All_Statels{}


class is_SwitchListTile_Setting extends All_Statels{

}
//stat_ThemeMode
class stat_ThemeMode extends All_Statels{}
